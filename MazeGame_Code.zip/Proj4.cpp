//Multi-Object, Multi-Texture Example
//Stephen J. Guy, 2025 

//This example demonstrates:
// Loading multiple models (a cube and a knot)
// Using multiple textures (wood and brick)
// Instancing (the teapot is drawn in two locations)
// Continuous keyboard input - arrows (moves knot up/down/left/right continuous when being held)
// Keyboard modifiers - shift (up/down arrows move knot in/out of screen when shift is pressed)
// Single key events - pressing 'c' changes color of a random teapot
// Mixing textures and colors for models
// Phong lighting
// Binding multiple textures to one shader

const char* INSTRUCTIONS = 
"***************\n"
"3D Maze Game - Find the goal (G) by collecting keys!\n"
"\n"
"WASD - Move forward/backward/strafe left/right\n"
"Mouse - Look around\n"
"Space - Jump\n"
"ESC - Quit\n"
"F - Toggle fullscreen\n"
"***************\n"
;

//Mac OS build: g++ multiObjectTexture.cpp -x c glad/glad.c -g -F/Library/Frameworks -framework SDL3 -framework OpenGL -o MultiObjTest
//Linux build:  clang++ -Wall multiObjectTexture.cpp -xc glad/glad.c -F ~/Library/Frameworks -framework SDL3 -Wl,-rpath,$HOME/Library/Frameworks && ./a.out 

#include "glad/glad.h"  //Include order can matter here
#if defined(__APPLE__) || defined(__linux__)
 #include <SDL3/SDL.h>
 #include <SDL3/SDL_opengl.h>
#else
 #include <SDL3/SDL.h>
 #include <SDL3/SDL_opengl.h>
#endif
#include <cstdio>

#define GLM_FORCE_RADIANS
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "glm/gtc/type_ptr.hpp"

#include <cstdio>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <cmath>

int screenWidth = 800; 
int screenHeight = 600;  
float timePast = 0;

bool DEBUG_ON = true;
GLuint InitShader(const char* vShaderFileName, const char* fShaderFileName);
bool fullscreen = false;
void Win2PPM(int width, int height);
// Update global size and GL viewport to match the window's pixel size (handles fullscreen/resizes)
static inline void UpdateViewport(SDL_Window* window){
    int w = 0, h = 0;
    SDL_GetWindowSizeInPixels(window, &w, &h);
    if(w > 0 && h > 0){
        screenWidth = w;
        screenHeight = h;
        glViewport(0, 0, screenWidth, screenHeight);
    }
}

float rand01(){
	return rand()/(float)RAND_MAX;
}

struct MapData {
	std::map<int, std::map<int, char>> grid;
	int width, height;
	float startX, startY;
};

struct Player {
	float x, y, z;
	float dirX, dirY;
	float pitch, yaw;
	float radius;
	float velocityZ;
	bool isJumping;
	std::map<char, bool> keys;
	char activeKey;
};

MapData loadMap(const char* filename);
void drawGeometry(int shaderProgram, int model1_start, int model1_numVerts, int model2_start, int model2_numVerts, int model3_start, int model3_numVerts);
void renderMap(int shaderProgram, MapData& map, Player& player, int* modelList, std::map<char, bool>& openDoors);
void updatePlayer(Player& player, MapData& map, bool wKey, bool aKey, bool sKey, bool dKey, bool spaceKey, float deltaTime, std::map<char, bool>& openDoors);
bool checkCollision(float x, float y, MapData& map, Player& player, std::map<char, bool>& openDoors);

int main(int argc, char *argv[]){
	SDL_Init(SDL_INIT_VIDEO);  //Initialize Graphics (for OpenGL)

    //Print the version of SDL we are using (should be 3.x or higher)
    const int sdl_linked = SDL_GetVersion();
    printf("\nCompiled against SDL version %d.%d.%d ...\n", SDL_VERSIONNUM_MAJOR(SDL_VERSION), SDL_VERSIONNUM_MINOR(SDL_VERSION), SDL_VERSIONNUM_MICRO(SDL_VERSION));
    printf("Linking against SDL version %d.%d.%d.\n", SDL_VERSIONNUM_MAJOR(sdl_linked), SDL_VERSIONNUM_MINOR(sdl_linked), SDL_VERSIONNUM_MICRO(sdl_linked));

	//Ask SDL to get a recent version of OpenGL (3.2 or greater)
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 2);

	//Create a window (title, width, height, flags)
	SDL_Window* window = SDL_CreateWindow("3D Maze Game", screenWidth, screenHeight, SDL_WINDOW_OPENGL);
    if (!window) {
        printf("SDL_CreateWindow Error: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

	//Create a context to draw in
	SDL_GLContext context = SDL_GL_CreateContext(window);
	
	//Load OpenGL extentions with GLAD
	if (gladLoadGLLoader((GLADloadproc)SDL_GL_GetProcAddress)){
		printf("\nOpenGL loaded\n");
		// Make sure the OpenGL viewport matches the window size on startup (after GL is ready)
		UpdateViewport(window);
		printf("Vendor:   %s\n", glGetString(GL_VENDOR));
		printf("Renderer: %s\n", glGetString(GL_RENDERER));
		printf("Version:  %s\n\n", glGetString(GL_VERSION));
	}
	else {
		printf("ERROR: Failed to initialize OpenGL context.\n");
		return -1;
	}
	
	//Here we will load two different model files 
	
	//Load Model 1
	std::ifstream modelFile;
	modelFile.open("models/cube.txt");
	int numLines = 0;
	if (modelFile.is_open()){
		modelFile >> numLines;
	}
	float* model1 = new float[numLines];
	for (int i = 0; i < numLines; i++){
		modelFile >> model1[i];
	}
	printf("%d\n",numLines);
	int numVertsCube = numLines/8;
	modelFile.close();
	
	//Load Model 2
	modelFile.open("models/teapot.txt");
	numLines = 0;
	if (modelFile.is_open()){
		modelFile >> numLines;
	}
	float* model2 = new float[numLines];
	for (int i = 0; i < numLines; i++){
		modelFile >> model2[i];
	}
	printf("%d\n",numLines);
	int numVertsTeapot = numLines/8;
	modelFile.close();

	//Load Model 3
	modelFile.open("models/knot.txt");
	numLines = 0;
	if (modelFile.is_open()){
		modelFile >> numLines;
	}
	float* model3 = new float[numLines];
	for (int i = 0; i < numLines; i++){
		modelFile >> model3[i];
	}
	printf("%d\n",numLines);
	int numVertsKnot = numLines/8;
	modelFile.close();
	
	//SJG: I load each model in a different array, then concatenate everything in one big array
	// This structure works, but there is room for improvement here. Eg., you should store the start
	// and end of each model a data structure or array somewhere.
	//Concatenate model arrays
	float* modelData = new float[(numVertsCube+numVertsTeapot+numVertsKnot)*8];
	std::copy(model1, model1+numVertsCube*8, modelData);
	std::copy(model2, model2+numVertsTeapot*8, modelData+numVertsCube*8);
	std::copy(model3, model3+numVertsKnot*8, modelData+(numVertsCube+numVertsTeapot)*8);
	int totalNumVerts = numVertsCube+numVertsTeapot+numVertsKnot;
	int startVertCube = 0;
	int startVertTeapot = numVertsCube;
	int startVertKnot = numVertsCube+numVertsTeapot;

	int modelList[6];
	modelList[0] = startVertCube;
	modelList[1] = numVertsCube;
	modelList[2] = startVertTeapot;
	modelList[3] = numVertsTeapot;
	modelList[4] = startVertKnot;
	modelList[5] = numVertsKnot;
	
	
	//// Allocate Texture 0 (Wood) ///////
	SDL_Surface* surface = SDL_LoadBMP("wood.bmp");
	if (surface==NULL){ //If it failed, print the error
        printf("Error: \"%s\"\n",SDL_GetError()); return 1;
    }
    GLuint tex0;
    glGenTextures(1, &tex0);
    
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, tex0);
    
    //What to do outside 0-1 range
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    
    //Load the texture into memory
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, surface->w,surface->h, 0, GL_BGR,GL_UNSIGNED_BYTE,surface->pixels);
    glGenerateMipmap(GL_TEXTURE_2D); //Mip maps the texture
    
    SDL_DestroySurface(surface);
    //// End Allocate Texture ///////


	//// Allocate Texture 1 (Brick) ///////
	SDL_Surface* surface1 = SDL_LoadBMP("brick.bmp");
	if (surface1==NULL){ //If it failed, print the error
        printf("Error: \"%s\"\n",SDL_GetError()); return 1;
    }
    GLuint tex1;
    glGenTextures(1, &tex1);
    
    //Load the texture into memory
    glActiveTexture(GL_TEXTURE1);
    
    glBindTexture(GL_TEXTURE_2D, tex1);
    //What to do outside 0-1 range
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, surface1->w,surface1->h, 0, GL_BGR,GL_UNSIGNED_BYTE,surface1->pixels);
    glGenerateMipmap(GL_TEXTURE_2D); //Mip maps the texture
    
    SDL_DestroySurface(surface1);
	//// End Allocate Texture ///////
	
	//Build a Vertex Array Object (VAO) to store mapping of shader attributse to VBO
	GLuint vao;
	glGenVertexArrays(1, &vao); //Create a VAO
	glBindVertexArray(vao); //Bind the above created VAO to the current context

	//Allocate memory on the graphics card to store geometry (vertex buffer object)
	GLuint vbo[1];
	glGenBuffers(1, vbo);  //Create 1 buffer called vbo
	glBindBuffer(GL_ARRAY_BUFFER, vbo[0]); //Set the vbo as the active array buffer (Only one buffer can be active at a time)
	glBufferData(GL_ARRAY_BUFFER, totalNumVerts*8*sizeof(float), modelData, GL_STATIC_DRAW); //upload vertices to vbo
	//GL_STATIC_DRAW means we won't change the geometry, GL_DYNAMIC_DRAW = geometry changes infrequently
	//GL_STREAM_DRAW = geom. changes frequently.  This effects which types of GPU memory is used
	
	int texturedShader = InitShader("textured-Vertex.glsl", "textured-Fragment.glsl");	
	
	//Tell OpenGL how to set fragment shader input 
	GLint posAttrib = glGetAttribLocation(texturedShader, "position");
	glVertexAttribPointer(posAttrib, 3, GL_FLOAT, GL_FALSE, 8*sizeof(float), 0);
	  //Attribute, vals/attrib., type, isNormalized, stride, offset
	glEnableVertexAttribArray(posAttrib);
	
	GLint normAttrib = glGetAttribLocation(texturedShader, "inNormal");
	glVertexAttribPointer(normAttrib, 3, GL_FLOAT, GL_FALSE, 8*sizeof(float), (void*)(5*sizeof(float)));
	glEnableVertexAttribArray(normAttrib);
	
	GLint texAttrib = glGetAttribLocation(texturedShader, "inTexcoord");
	glEnableVertexAttribArray(texAttrib);
	glVertexAttribPointer(texAttrib, 2, GL_FLOAT, GL_FALSE, 8*sizeof(float), (void*)(3*sizeof(float)));

	GLint uniView = glGetUniformLocation(texturedShader, "view");
	GLint uniProj = glGetUniformLocation(texturedShader, "proj");

	glBindVertexArray(0); //Unbind the VAO in case we want to create a new one
	                       	
	glEnable(GL_DEPTH_TEST);  

	printf("%s\n",INSTRUCTIONS);

	const char* mapFile = argc > 1 ? argv[1] : "map1.txt";
	MapData map = loadMap(mapFile);

	Player player;
	player.x = map.startX;
	player.y = map.startY;
	player.z = 0.5f;
	player.pitch = 0.0f;
	player.yaw = 0.0f;
	player.radius = 0.3f;
	player.velocityZ = 0.0f;
	player.isJumping = false;
	player.activeKey = '\0';

	std::map<char, bool> openDoors;

	bool wKey = false, aKey = false, sKey = false, dKey = false, spaceKey = false;
	bool mouseCaptured = false;
	
	//Event Loop (Loop forever processing each event as fast as possible)
	SDL_Event windowEvent;
	bool quit = false;
	float lastTime = SDL_GetTicks()/1000.f;
	bool won = false;

	while (!quit){
		float currentTime = SDL_GetTicks()/1000.f;
		float deltaTime = currentTime - lastTime;
		lastTime = currentTime;

		while (SDL_PollEvent(&windowEvent)){  //inspect all events in the queue
			if (windowEvent.type == SDL_EVENT_QUIT) quit = true;
			//List of keycodes: https://wiki.libsdl.org/SDL_Keycode - You can catch many special keys
			//Scancode referes to a keyboard position, keycode referes to the letter (e.g., EU keyboards)
			if (windowEvent.type == SDL_EVENT_KEY_UP && windowEvent.key.key == SDLK_ESCAPE) 
				quit = true; //Exit event loop
			if (windowEvent.type == SDL_EVENT_KEY_UP && windowEvent.key.key == SDLK_F){ //If "f" is pressed
				fullscreen = !fullscreen;
				SDL_SetWindowFullscreen(window, fullscreen); //Toggle fullscreen
				UpdateViewport(window); // sync GL viewport to new size
			}

			if (windowEvent.type == SDL_EVENT_KEY_DOWN && windowEvent.key.key == SDLK_W) wKey = true;
			if (windowEvent.type == SDL_EVENT_KEY_UP && windowEvent.key.key == SDLK_W) wKey = false;
			if (windowEvent.type == SDL_EVENT_KEY_DOWN && windowEvent.key.key == SDLK_A) aKey = true;
			if (windowEvent.type == SDL_EVENT_KEY_UP && windowEvent.key.key == SDLK_A) aKey = false;
			if (windowEvent.type == SDL_EVENT_KEY_DOWN && windowEvent.key.key == SDLK_S) sKey = true;
			if (windowEvent.type == SDL_EVENT_KEY_UP && windowEvent.key.key == SDLK_S) sKey = false;
			if (windowEvent.type == SDL_EVENT_KEY_DOWN && windowEvent.key.key == SDLK_D) dKey = true;
			if (windowEvent.type == SDL_EVENT_KEY_UP && windowEvent.key.key == SDLK_D) dKey = false;
			if (windowEvent.type == SDL_EVENT_KEY_DOWN && windowEvent.key.key == SDLK_SPACE) spaceKey = true;
			if (windowEvent.type == SDL_EVENT_KEY_UP && windowEvent.key.key == SDLK_SPACE) spaceKey = false;

			if (windowEvent.type == SDL_EVENT_MOUSE_MOTION && mouseCaptured){
				float sensitivity = 0.002f;
				player.yaw -= windowEvent.motion.xrel * sensitivity;
				player.pitch -= windowEvent.motion.yrel * sensitivity;
				if (player.pitch > 1.5f) player.pitch = 1.5f;
				if (player.pitch < -1.5f) player.pitch = -1.5f;
			}

			// Update viewport if the window pixel size changes (resize/fullscreen)
			if (windowEvent.type == SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED){
				UpdateViewport(window);
			}

			if (windowEvent.type == SDL_EVENT_MOUSE_BUTTON_DOWN){
				if(!mouseCaptured){
					SDL_SetWindowRelativeMouseMode(window, true);
					mouseCaptured = true;
				}
			}

		}

		if(!won){
			updatePlayer(player, map, wKey, aKey, sKey, dKey, spaceKey, deltaTime, openDoors);

			int gridX = (int)player.x;
			int gridY = (int)player.y;
			if(map.grid.count(gridY) && map.grid[gridY].count(gridX)){
				char tile = map.grid[gridY][gridX];
				if(tile >= 'a' && tile <= 'e'){
					if(!player.keys[tile]){
						player.keys[tile] = true;
						player.activeKey = tile;
					}
				}
				if(tile == 'G'){
					won = true;
					printf("\n*** YOU WON! ***\n");
				}
			}
		}
      
		// Clear the screen to default color
		glClearColor(.2f, 0.4f, 0.8f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		glUseProgram(texturedShader);

		timePast = SDL_GetTicks()/1000.f; 

		player.dirX = cos(player.yaw) * cos(player.pitch);
		player.dirY = sin(player.yaw) * cos(player.pitch);
		float dirZ = sin(player.pitch);

		glm::mat4 view = glm::lookAt(
		glm::vec3(player.x, player.y, player.z),  //Cam Position
		glm::vec3(player.x + player.dirX, player.y + player.dirY, player.z + dirZ),  //Look at point
		glm::vec3(0.0f, 0.0f, 1.0f)); //Up
		glUniformMatrix4fv(uniView, 1, GL_FALSE, glm::value_ptr(view));

		glm::mat4 proj = glm::perspective(glm::radians(75.0f), screenWidth / (float) screenHeight, 0.1f, 100.0f); //FOV, aspect, near, far
		glUniformMatrix4fv(uniProj, 1, GL_FALSE, glm::value_ptr(proj));

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, tex0);
		glUniform1i(glGetUniformLocation(texturedShader, "tex0"), 0);

		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, tex1);
		glUniform1i(glGetUniformLocation(texturedShader, "tex1"), 1);

		glBindVertexArray(vao);
		renderMap(texturedShader, map, player, modelList, openDoors);

		SDL_GL_SwapWindow(window); //Double buffering
	}
	
    delete[] modelData;
    delete[] model1;
    delete[] model2;
	delete[] model3;

	//Clean Up
	glDeleteProgram(texturedShader);
    glDeleteBuffers(1, vbo);
    glDeleteVertexArrays(1, &vao);

	SDL_GL_DestroyContext(context);
	SDL_Quit();
	return 0;
}

MapData loadMap(const char* filename){
	MapData map;
	std::ifstream file(filename);
	if(!file.is_open()){
		printf("Error: Could not open map file %s\n", filename);
		exit(1);
	}

	file >> map.width >> map.height;
	std::string line;
	std::getline(file, line);

	for(int y = 0; y < map.height; y++){
		std::getline(file, line);
		for(int x = 0; x < line.length() && x < map.width; x++){
			char c = line[x];
			map.grid[y][x] = c;
			if(c == 'S'){
				map.startX = x + 0.5f;
				map.startY = y + 0.5f;
			}
		}
	}

	file.close();
	return map;
}

void updatePlayer(Player& player, MapData& map, bool wKey, bool aKey, bool sKey, bool dKey, bool spaceKey, float deltaTime, std::map<char, bool>& openDoors){
	float speed = 3.0f;
	float newX = player.x;
	float newY = player.y;

	if(wKey){
		newX += player.dirX * speed * deltaTime;
		newY += player.dirY * speed * deltaTime;
	}
	if(sKey){
		newX -= player.dirX * speed * deltaTime;
		newY -= player.dirY * speed * deltaTime;
	}
	if(aKey){
		newX -= player.dirY * speed * deltaTime;
		newY += player.dirX * speed * deltaTime;
	}
	if(dKey){
		newX += player.dirY * speed * deltaTime;
		newY -= player.dirX * speed * deltaTime;
	}

	if(!checkCollision(newX, player.y, map, player, openDoors)){
		player.x = newX;
	}
	if(!checkCollision(player.x, newY, map, player, openDoors)){
		player.y = newY;
	}

	if(spaceKey && !player.isJumping && player.z <= 0.5f){
		player.velocityZ = 5.0f;
		player.isJumping = true;
	}

	player.velocityZ -= 15.0f * deltaTime;
	player.z += player.velocityZ * deltaTime;

	if(player.z <= 0.5f){
		player.z = 0.5f;
		player.velocityZ = 0.0f;
		player.isJumping = false;
	}
}

bool checkCollision(float x, float y, MapData& map, Player& player, std::map<char, bool>& openDoors){
	for(int dx = -1; dx <= 1; dx++){
		for(int dy = -1; dy <= 1; dy++){
			float checkX = x + dx * player.radius * 0.7f;
			float checkY = y + dy * player.radius * 0.7f;
			int gridX = (int)checkX;
			int gridY = (int)checkY;

			if(gridX < 0 || gridX >= map.width || gridY < 0 || gridY >= map.height){
				return true;
			}

			if(map.grid.count(gridY) && map.grid[gridY].count(gridX)){
				char tile = map.grid[gridY][gridX];
				if(tile == 'W'){
					return true;
				}
				if(tile >= 'A' && tile <= 'E'){
					char keyNeeded = tile - 'A' + 'a';
					if(player.keys[keyNeeded]){
						openDoors[tile] = true;
					} else {
						return true;
					}
				}
			}
		}
	}
	return false;
}

void renderMap(int shaderProgram, MapData& map, Player& player, int* modelList, std::map<char, bool>& openDoors){
	GLint uniModel = glGetUniformLocation(shaderProgram, "model");
	GLint uniColor = glGetUniformLocation(shaderProgram, "inColor");
	GLint uniTexID = glGetUniformLocation(shaderProgram, "texID");

	glm::mat4 model = glm::mat4(1);
	model = glm::translate(model, glm::vec3(map.width/2.0f, map.height/2.0f, -0.5f));
	model = glm::scale(model, glm::vec3(map.width, map.height, 1.0f));
	glUniformMatrix4fv(uniModel, 1, GL_FALSE, glm::value_ptr(model));
	glUniform1i(uniTexID, 1);
	glUniform3f(uniColor, 1.0f, 1.0f, 1.0f);
	glDrawArrays(GL_TRIANGLES, modelList[0], modelList[1]);

	for(auto& row : map.grid){
		int y = row.first;
		for(auto& cell : row.second){
			int x = cell.first;
			char tile = cell.second;

			if(tile == 'W'){
				model = glm::mat4(1);
				model = glm::translate(model, glm::vec3(x + 0.5f, y + 0.5f, 0.5f));
				model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
				glUniformMatrix4fv(uniModel, 1, GL_FALSE, glm::value_ptr(model));
				glUniform1i(uniTexID, 0);
				glUniform3f(uniColor, 0.7f, 0.7f, 0.7f);
				glDrawArrays(GL_TRIANGLES, modelList[0], modelList[1]);
			}
			else if(tile >= 'A' && tile <= 'E'){
				if(!openDoors[tile]){
					model = glm::mat4(1);
					model = glm::translate(model, glm::vec3(x + 0.5f, y + 0.5f, 0.5f));
					model = glm::scale(model, glm::vec3(0.9f, 0.9f, 1.0f));
					glUniformMatrix4fv(uniModel, 1, GL_FALSE, glm::value_ptr(model));
					glUniform1i(uniTexID, -1);
					
					float r = (tile == 'A') ? 1.0f : ((tile == 'C' || tile == 'D') ? 0.0f : 1.0f);
					float g = (tile == 'B') ? 1.0f : ((tile == 'D') ? 1.0f : 0.0f);
					float b = (tile == 'C') ? 1.0f : ((tile == 'D' || tile == 'E') ? 1.0f : 0.0f);
					
					glUniform3f(uniColor, r, g, b);
					glDrawArrays(GL_TRIANGLES, modelList[0], modelList[1]);
				}
			}
			else if(tile >= 'a' && tile <= 'e'){
				if(player.keys[tile] && player.activeKey == tile){
					model = glm::mat4(1);
					// Place carried key in front of player; reduce distance if it would clip a wall/door
					float dist = 0.4f;
					for(float test = dist; test >= 0.15f; test -= 0.05f){
						float tx = player.x + player.dirX * test;
						float ty = player.y + player.dirY * test;
						int gx = (int)tx, gy = (int)ty;
						bool blocked = false;
						if(gx < 0 || gy < 0 || gx >= map.width || gy >= map.height){ blocked = true; }
						else if(map.grid.count(gy) && map.grid[gy].count(gx)){
							char t = map.grid[gy][gx];
							blocked = (t == 'W') || (t >= 'A' && t <= 'E' && !openDoors[t]);
						}
						if(!blocked){ dist = test; break; }
					}
					model = glm::translate(model, glm::vec3(player.x + player.dirX * dist, player.y + player.dirY * dist, player.z - 0.2f));
					model = glm::rotate(model, timePast * 2.0f, glm::vec3(0.0f, 0.0f, 1.0f));
					model = glm::scale(model, glm::vec3(0.09f, 0.09f, 0.09f));
					glUniformMatrix4fv(uniModel, 1, GL_FALSE, glm::value_ptr(model));
					glUniform1i(uniTexID, -1);
					
					float r = (tile == 'a') ? 1.0f : ((tile == 'c' || tile == 'd') ? 0.0f : 1.0f);
					float g = (tile == 'b') ? 1.0f : ((tile == 'd') ? 1.0f : 0.0f);
					float b = (tile == 'c') ? 1.0f : ((tile == 'd' || tile == 'e') ? 1.0f : 0.0f);
					
					glUniform3f(uniColor, r, g, b);
					glDrawArrays(GL_TRIANGLES, modelList[2], modelList[3]);
				} else if(!player.keys[tile]){
					model = glm::mat4(1);
					model = glm::translate(model, glm::vec3(x + 0.5f, y + 0.5f, 0.3f));
					model = glm::rotate(model, timePast * 2.0f, glm::vec3(0.0f, 0.0f, 1.0f));
					model = glm::scale(model, glm::vec3(0.3f, 0.3f, 0.3f));
					glUniformMatrix4fv(uniModel, 1, GL_FALSE, glm::value_ptr(model));
					glUniform1i(uniTexID, -1);
					
					float r = (tile == 'a') ? 1.0f : ((tile == 'c' || tile == 'd') ? 0.0f : 1.0f);
					float g = (tile == 'b') ? 1.0f : ((tile == 'd') ? 1.0f : 0.0f);
					float b = (tile == 'c') ? 1.0f : ((tile == 'd' || tile == 'e') ? 1.0f : 0.0f);
					
					glUniform3f(uniColor, r, g, b);
					glDrawArrays(GL_TRIANGLES, modelList[2], modelList[3]);
				}
			}
			else if(tile == 'G'){
				model = glm::mat4(1);
				model = glm::translate(model, glm::vec3(x + 0.5f, y + 0.5f, 0.5f));
				model = glm::rotate(model, timePast, glm::vec3(0.0f, 0.0f, 1.0f));
				model = glm::scale(model, glm::vec3(0.5f, 0.5f, 0.5f));
				glUniformMatrix4fv(uniModel, 1, GL_FALSE, glm::value_ptr(model));
				glUniform1i(uniTexID, -1);
				glUniform3f(uniColor, 1.0f, 1.0f, 0.0f);
				glDrawArrays(GL_TRIANGLES, modelList[4], modelList[5]);
			}
		}
	}
}

// Create a NULL-terminated string by reading the provided file
static char* readShaderSource(const char* shaderFile){
	FILE *fp;
	long length;
	char *buffer;

	// open the file containing the text of the shader code
	fp = fopen(shaderFile, "r");

	// check for errors in opening the file
	if (fp == NULL) {
		printf("can't open shader source file %s\n", shaderFile);
		return NULL;
	}

	// determine the file size
	fseek(fp, 0, SEEK_END); // move position indicator to the end of the file;
	length = ftell(fp);  // return the value of the current position

	// allocate a buffer with the indicated number of bytes, plus one
	buffer = new char[length + 1];

	// read the appropriate number of bytes from the file
	fseek(fp, 0, SEEK_SET);  // move position indicator to the start of the file
	fread(buffer, 1, length, fp); // read all of the bytes

	// append a NULL character to indicate the end of the string
	buffer[length] = '\0';

	// close the file
	fclose(fp);

	// return the string
	return buffer;
}

// Create a GLSL program object from vertex and fragment shader files
GLuint InitShader(const char* vShaderFileName, const char* fShaderFileName){
	GLuint vertex_shader, fragment_shader;
	GLchar *vs_text, *fs_text;
	GLuint program;

	// check GLSL version
	printf("GLSL version: %s\n\n", glGetString(GL_SHADING_LANGUAGE_VERSION));

	// Create shader handlers
	vertex_shader = glCreateShader(GL_VERTEX_SHADER);
	fragment_shader = glCreateShader(GL_FRAGMENT_SHADER);

	// Read source code from shader files
	vs_text = readShaderSource(vShaderFileName);
	fs_text = readShaderSource(fShaderFileName);

	// error check
	if (vs_text == NULL) {
		printf("Failed to read from vertex shader file %s\n", vShaderFileName);
		exit(1);
	} else if (DEBUG_ON) {
		printf("Vertex Shader:\n=====================\n");
		printf("%s\n", vs_text);
		printf("=====================\n\n");
	}
	if (fs_text == NULL) {
		printf("Failed to read from fragent shader file %s\n", fShaderFileName);
		exit(1);
	} else if (DEBUG_ON) {
		printf("\nFragment Shader:\n=====================\n");
		printf("%s\n", fs_text);
		printf("=====================\n\n");
	}

	// Load Vertex Shader
	const char *vv = vs_text;
	glShaderSource(vertex_shader, 1, &vv, NULL);  //Read source
	glCompileShader(vertex_shader); // Compile shaders
	
	// Check for errors
	GLint  compiled;
	glGetShaderiv(vertex_shader, GL_COMPILE_STATUS, &compiled);
	if (!compiled) {
		printf("Vertex shader failed to compile:\n");
		if (DEBUG_ON) {
			GLint logMaxSize, logLength;
			glGetShaderiv(vertex_shader, GL_INFO_LOG_LENGTH, &logMaxSize);
			printf("printing error message of %d bytes\n", logMaxSize);
			char* logMsg = new char[logMaxSize];
			glGetShaderInfoLog(vertex_shader, logMaxSize, &logLength, logMsg);
			printf("%d bytes retrieved\n", logLength);
			printf("error message: %s\n", logMsg);
			delete[] logMsg;
		}
		exit(1);
	}
	
	// Load Fragment Shader
	const char *ff = fs_text;
	glShaderSource(fragment_shader, 1, &ff, NULL);
	glCompileShader(fragment_shader);
	glGetShaderiv(fragment_shader, GL_COMPILE_STATUS, &compiled);
	
	//Check for Errors
	if (!compiled) {
		printf("Fragment shader failed to compile\n");
		if (DEBUG_ON) {
			GLint logMaxSize, logLength;
			glGetShaderiv(fragment_shader, GL_INFO_LOG_LENGTH, &logMaxSize);
			printf("printing error message of %d bytes\n", logMaxSize);
			char* logMsg = new char[logMaxSize];
			glGetShaderInfoLog(fragment_shader, logMaxSize, &logLength, logMsg);
			printf("%d bytes retrieved\n", logLength);
			printf("error message: %s\n", logMsg);
			delete[] logMsg;
		}
		exit(1);
	}

	// Create the program
	program = glCreateProgram();

	// Attach shaders to program
	glAttachShader(program, vertex_shader);
	glAttachShader(program, fragment_shader);

	// Link and set program to use
	glLinkProgram(program);

	return program;
}
